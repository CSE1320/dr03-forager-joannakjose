import NavBar from '../../components/NavBar';

export default function MushroomComparisonPage() {
  return (
    <div className="page">
      <h1>Mushroom Comparison Page</h1>
      <NavBar />
    </div>
  );
}
